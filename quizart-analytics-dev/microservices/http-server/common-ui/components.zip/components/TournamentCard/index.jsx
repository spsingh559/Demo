import React from 'react';

export class TournamentCard extends React.Component {
    render <small>This is the TournamentCard</small>
}