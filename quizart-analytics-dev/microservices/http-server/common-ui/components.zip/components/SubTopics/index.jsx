import React from 'react';
import SubTopicContainer from './SubTopicContainer';

var SubTopicsContainer = React.createClass({
  render: function(){
    return(
      <div>
      <SubTopicContainer />
      </div>
    );
  }
});

export default SubTopicContainer;
