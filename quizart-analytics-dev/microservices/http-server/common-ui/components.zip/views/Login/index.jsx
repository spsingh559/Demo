import React from 'react';

import LoginForm from './login';


export default class Login extends React.Component {
  render() {

    return (
              <LoginForm/>

      );
  }
};
