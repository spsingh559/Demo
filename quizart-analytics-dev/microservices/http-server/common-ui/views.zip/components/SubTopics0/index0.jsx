import React from 'react';
import SubTopicContainer0 from './SubTopicContainer0';

var SubTopicsContainer0 = React.createClass({
  render: function(){
    return(
      <div>
      <SubTopicContainer0 />
      </div>
    );
  }
});

export default SubTopicContainer0;
